%MAKE_FIGURE_SECTION2_TAXONOMY Clean Section 2 taxonomy schematic.
%
% The figure is a compact timing and validation map for the four cases in
% Section 2. Explanatory detail belongs in the caption/note and Table 1.

figures_root = fileparts(mfilename('fullpath'));
make_taxonomy_figure(figures_root);

function make_taxonomy_figure(figures_root)
out_pdf = fullfile(figures_root, 'Figure_Section2_Taxonomy.pdf');
out_png = fullfile(figures_root, 'Figure_Section2_Taxonomy.png');

c = palette();
fig = figure('Visible', 'off', 'Color', 'w', 'Units', 'inches', ...
    'Position', [1 1 11.2 7.3]);
tiledlayout(fig, 2, 2, 'Padding', 'compact', 'TileSpacing', 'compact');

ax = nexttile; panel_a(ax, c);
ax = nexttile; panel_b(ax, c);
ax = nexttile; panel_c(ax, c);
ax = nexttile; panel_d(ax, c);

exportgraphics(fig, out_pdf, 'ContentType', 'vector', 'BackgroundColor', 'white');
exportgraphics(fig, out_png, 'Resolution', 300, 'BackgroundColor', 'white');
close(fig);

fprintf('Wrote %s\n', out_pdf);
fprintf('Wrote %s\n', out_png);
end

function c = palette()
c.dark = [0.08 0.29 0.31];
c.dark2 = [0.11 0.36 0.38];
c.pale = [0.91 0.87 0.78];
c.border = [0.25 0.25 0.25];
c.blue = [0.05 0.36 0.57];
c.orange = [0.88 0.42 0.08];
c.red = [0.68 0.17 0.16];
c.green = [0.66 0.72 0.63];
c.gray = [0.45 0.45 0.45];
end

function setup_panel(ax)
cla(ax);
hold(ax, 'on');
axis(ax, [0 1 0 1]);
axis(ax, 'off');
set(ax, 'YDir', 'normal');
end

function panel_title(ax, s)
title(ax, s, 'FontName', 'Helvetica', 'FontSize', 12.5, ...
    'FontWeight', 'bold', 'Color', [0.08 0.08 0.08]);
end

function label(ax, x, y, s, color, fs, align)
if nargin < 7, align = 'center'; end
text(ax, x, y, s, 'HorizontalAlignment', align, 'VerticalAlignment', 'middle', ...
    'FontName', 'Helvetica', 'FontSize', fs, 'Color', color, ...
    'Margin', 1.5, 'BackgroundColor', 'w', 'EdgeColor', 'none');
end

function draw_arrow(ax, x1, y1, x2, y2, color, lw, style)
if nargin < 8, style = '-'; end
quiver(ax, x1, y1, x2-x1, y2-y1, 0, 'Color', color, ...
    'LineWidth', lw, 'LineStyle', style, 'MaxHeadSize', 0.22, ...
    'AutoScale', 'off');
end

function draw_box(ax, x, y, w, h, face, edge, lw)
rectangle(ax, 'Position', [x y w h], 'FaceColor', face, ...
    'EdgeColor', edge, 'LineWidth', lw);
end

function draw_missing_cells(ax, cells, c)
for r = 1:size(cells, 1)
    draw_box(ax, cells(r,1), cells(r,2), cells(r,3), cells(r,4), c.pale, c.pale, 0.1);
end
end

function panel_a(ax, c)
setup_panel(ax);
panel_title(ax, 'A. Delayed release');
x0 = 0.07; y0 = 0.11; w = 0.86; h = 0.57;
draw_box(ax, x0, y0, w, h, c.pale, c.border, 0.8);

front = [0.78 0.73 0.70 0.68 0.72 0.69 0.63 0.76 0.67 ...
         0.60 0.70 0.67 0.64 0.61 0.58 0.66 0.60 0.75 0.68 0.58 0.70 0.66];
nx = numel(front);
dx = w / nx;
for j = 1:nx
    draw_box(ax, x0 + (j-1)*dx, y0, dx*1.01, h*front(j), c.dark, c.dark, 0.1);
end

miss = [
    x0+0.03*w y0+0.22*h 0.018 0.018
    x0+0.16*w y0+0.06*h 0.018 0.018
    x0+0.25*w y0+0.01*h 0.018 0.018
    x0+0.45*w y0+0.12*h 0.018 0.018
    x0+0.60*w y0+0.46*h 0.018 0.018
    x0+0.80*w y0+0.24*h 0.018 0.018
    x0+0.93*w y0+0.10*h 0.018 0.018];
draw_missing_cells(ax, miss, c);

yd = y0 + 0.82*h;
plot(ax, [x0 x0+w], [yd yd], 'Color', c.blue, 'LineWidth', 1.6);
label(ax, x0+0.10*w, yd+0.045, 'decision vintage', c.blue, 10, 'center');

xu = x0 + 0.65*w; yu = yd + 0.004;
plot(ax, xu, yu, 'o', 'MarkerSize', 5.5, 'LineWidth', 1.6, ...
    'Color', c.red, 'MarkerFaceColor', 'w');
label(ax, xu-0.065, yu+0.055, 'unreleased cell', [0.10 0.10 0.10], 9.5, 'center');

xl = x0 + 0.86*w; yl = yd + 0.004;
draw_box(ax, xl-0.012, yd-0.015, 0.024, 0.030, c.dark, c.dark, 0.1);
label(ax, xl+0.055, yd+0.055, 'later release', [0.10 0.10 0.10], 9.5, 'center');
draw_arrow(ax, xu+0.025, yu+0.035, xl-0.020, yl+0.035, c.red, 1.7, '--');
label(ax, (xu+xl)/2, yu+0.120, 'validation', c.red, 9.5, 'center');

xlabel_like(ax, 'units');
ylabel_like(ax, 'time');
end

function panel_b(ax, c)
setup_panel(ax);
panel_title(ax, 'B. Mixed frequency');
x0 = 0.12; y0 = 0.14; w = 0.72; h = 0.62;
draw_box(ax, x0, y0, w, h, c.pale, c.border, 0.8);
label(ax, x0+0.38*w, y0+h+0.085, 'high-frequency grid', [0.10 0.10 0.10], 10.5, 'center');

nr = 5;
for r = 1:nr
    yy = y0 + (r-0.5)*h/nr;
    plot(ax, [x0 x0+w], [yy yy], 'Color', c.dark, 'LineWidth', 6.8);
    plot(ax, [x0 x0+w], [yy yy], 'Color', c.orange, 'LineWidth', 0.7);
    text(ax, x0-0.025, yy, sprintf('t%d', r), 'FontName', 'Helvetica', ...
        'FontSize', 8.5, 'HorizontalAlignment', 'right', 'VerticalAlignment', 'middle');
end

marker_x = x0 + w*[0.28 0.34 0.43 0.72 0.95];
for r = 1:nr
    yy = y0 + (r-0.5)*h/nr;
    for mx = marker_x
        draw_box(ax, mx-0.009, yy-0.040, 0.018, 0.040, c.dark, c.dark, 0.1);
    end
end
for mx = marker_x([2 4])
    plot(ax, mx, y0+h-0.05, 's', 'MarkerSize', 4.8, 'MarkerFaceColor', c.orange, ...
        'MarkerEdgeColor', c.orange);
end
label(ax, x0+0.58*w, y0+h-0.045, 'low-frequency release', c.orange, 9.5, 'center');

draw_arrow(ax, x0+0.66*w, y0+0.49*h, x0+0.82*w, y0+0.49*h, c.red, 1.8, '-');
label(ax, x0+0.86*w, y0+0.49*h, sprintf('aggregation\nrestriction'), [0.10 0.10 0.10], 9.2, 'center');

xlabel_like(ax, 'units');
ylabel_like(ax, 'time');
end

function panel_c(ax, c)
setup_panel(ax);
panel_title(ax, 'C. Evaluable missingness');
x0 = 0.07; y0 = 0.14; w = 0.86; h = 0.62;
draw_box(ax, x0, y0, w, h, c.dark, c.border, 0.8);
split = x0 + 0.50*w;
plot(ax, [split split], [y0 y0+h], 'Color', [0.85 0.85 0.85], 'LineWidth', 1.0);

plot(ax, [x0+0.02*w split-0.02*w], [y0+h+0.025 y0+h+0.025], 'Color', c.blue, 'LineWidth', 1.7);
plot(ax, [split+0.02*w x0+w-0.02*w], [y0+h+0.025 y0+h+0.025], 'Color', c.orange, 'LineWidth', 1.7);
label(ax, x0+0.26*w, y0+h+0.055, 'target population', c.blue, 10, 'center');
label(ax, split+0.25*w, y0+h+0.055, 'validation population', c.orange, 10, 'center');

draw_box(ax, x0+0.01*w, y0+0.58*h, 0.25*w, 0.28*h, c.pale, c.pale, 0.1);
draw_box(ax, x0+0.30*w, y0+0.18*h, 0.17*w, 0.30*h, c.pale, c.pale, 0.1);

xs = split + w*[0.08 0.20 0.33];
ys = y0 + h*[0.20 0.38 0.55 0.72];
for xx = xs
    for yy = ys
        rectangle(ax, 'Position', [xx-0.010 yy-0.010 0.020 0.020], ...
            'FaceColor', 'none', 'EdgeColor', c.orange, 'LineWidth', 1.4);
    end
end
label(ax, split+0.26*w, y0+0.16*h, 'held-out / comparable', c.orange, 9.3, 'center');
draw_arrow(ax, split+0.44*w, y0+0.83*h, split+0.44*w, y0+0.30*h, c.red, 1.7, '-');
label(ax, split+0.44*w, y0+0.88*h, 'validation stream', c.red, 9.5, 'center');

xlabel_like(ax, 'units and validation objects');
ylabel_like(ax, 'time');
end

function panel_d(ax, c)
setup_panel(ax);
panel_title(ax, 'D. Completed-panel evaluation');

x1 = 0.06; y0 = 0.18; w = 0.31; h = 0.52;
x2 = 0.64;
label(ax, x1+w/2, y0+h+0.070, 'decision vintage', [0.10 0.10 0.10], 10, 'center');
label(ax, x2+w/2, y0+h+0.070, 'completed panel', [0.10 0.10 0.10], 10, 'center');

draw_panel_matrix(ax, x1, y0, w, h, c, false);
draw_panel_matrix(ax, x2, y0, w, h, c, true);

draw_arrow(ax, x1+w+0.06, y0+0.50*h, x2-0.06, y0+0.50*h, c.blue, 1.9, '-');
label(ax, 0.50, y0+0.64*h, 'completion rule', [0.10 0.10 0.10], 9.5, 'center');

rectangle(ax, 'Position', [x2+0.03*w y0+0.05*h 0.90*w 0.88*h], ...
    'FaceColor', 'none', 'EdgeColor', c.red, 'LineWidth', 2.0);
label(ax, x2+0.57*w, y0+0.18*h, 'target loss', c.red, 10, 'center');

xlabel_like(ax, 'units');
ylabel_like(ax, 'time');
end

function draw_panel_matrix(ax, x, y, w, h, c, completed)
draw_box(ax, x, y, w, h, c.pale, c.border, 0.8);
front = [0.74 0.74 0.78 0.78 0.82 0.82 0.86 0.86 0.90 0.90];
nx = numel(front);
dx = w / nx;
for j = 1:nx
    draw_box(ax, x + (j-1)*dx, y, dx*1.01, h*front(j), c.dark, c.dark, 0.1);
end
if completed
    rectangle(ax, 'Position', [x y+0.72*h w 0.28*h], ...
        'FaceColor', c.green, 'EdgeColor', 'none');
end
miss = [
    x+0.05*w y+0.45*h 0.018 0.018
    x+0.29*w y+0.10*h 0.018 0.018
    x+0.50*w y+0.83*h 0.018 0.018
    x+0.63*w y+0.42*h 0.018 0.018
    x+0.82*w y+0.78*h 0.018 0.018
    x+0.92*w y+0.08*h 0.018 0.018];
if completed
    miss(:,3:4) = 0.014;
end
draw_missing_cells(ax, miss, c);
end

function xlabel_like(ax, s)
text(ax, 0.50, 0.060, s, 'FontName', 'Helvetica', 'FontSize', 9.5, ...
    'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
    'Color', [0.10 0.10 0.10]);
end

function ylabel_like(ax, s)
text(ax, 0.025, 0.45, s, 'FontName', 'Helvetica', 'FontSize', 9.5, ...
    'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
    'Rotation', 90, 'Color', [0.10 0.10 0.10]);
end
